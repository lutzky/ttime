#!/bin/sh

export LC_ALL="he_IL.UTF-8"
export LANG="he_IL.UTF-8"
export LANGUAGE="he_IL.UTF-8"

rake
