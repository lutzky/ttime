class String
  def single_space
    gsub(/ +/,' ')
  end
end
