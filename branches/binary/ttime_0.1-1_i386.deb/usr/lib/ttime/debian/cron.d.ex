#
# Regular cron jobs for the ttime package
#
0 4	* * *	root	ttime_maintenance
