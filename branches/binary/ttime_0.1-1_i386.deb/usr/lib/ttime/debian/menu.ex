?package(ttime):needs="X11|text|vc|wm" section="Apps/see-menu-manual"\
  title="ttime" command="/usr/bin/ttime"
