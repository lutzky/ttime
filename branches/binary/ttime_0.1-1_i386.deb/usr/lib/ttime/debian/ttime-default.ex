# Defaults for ttime initscript
# sourced by /etc/init.d/ttime
# installed at /etc/default/ttime by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
