require 'thread'
require 'monitor'


module TTime
  module Web
    class CallRequest < Monitor

      attr_reader :cond
      attr_writer :cond


      attr_reader :req, :resp
      attr_writer :req, :resp


      def initialize(req, resp)
        @cond = self.new_cond
        @req = req
        @resp = resp
      end

      
    end
  end
end
