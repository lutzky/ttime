require 'webrick'
require 'yaml'
require 'thread'
require 'call_request'

module TTime
  module Web
    class HookManager
      include WEBrick

      def initialize(config = {})
        config.update(:Port => 1984)
        @server = WEBrick::HTTPServer.new(config)
        @hooks = {'/test/nil' => {}}
      end

      def start_server()
        hooked_servlet = Class.new(HookServlet)
        hook_list = @hooks
        @queue = Queue.new
        queue = @queue

        hooked_servlet.class_eval do
#         @@hooks = hook_list.dup
          @@queue = queue

          def queue
            @@queue
          end

          def hooks
            @@hooks
          end
        end

        @server.mount('/ttime/', hooked_servlet)
        @server.start()
        @running = true
        while @running
          while @queue.empty?
            sleep 0.01
          end
          while not @queue.empty?
            cr = @queue.pop
            manage_hook(cr)
            cr.cond.broadcast
          end

        end
      end

      def stop_server()
        @server.shutdown
        @running = false
      end

      def hook(hook,&target)
        @hooks[hook] = target
      end
    end

    class HookServlet < WEBrick::HTTPServlet::AbstractServlet
      def do_GET(req,resp)
        # the method hooks should be implemented by a class extending 
        # this one, otherwise this will fail.
        # I reccomend using the class_eval method for this porpouse

        rc = CallRequest.new(req, resp)
        queue << rc
        rc.cond.wait
      end

      alias do_POST do_GET

    end
  end
end



